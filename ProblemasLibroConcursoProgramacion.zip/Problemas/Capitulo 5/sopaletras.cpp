#include <cstring>
#include <iostream>

using namespace std; 

// Variables globales para facilitar el codigo
// Tabla para la sopa
char sopa[55][55];
char pal[55];
// Tama�o de la sopa
int m,n;

/* Funcion que recibe una una posicion
y devuelve si en esa posicion comienza o no esa palabra
*/

int esta_pal(int y,int x){
    
    int i,j;
    // Tama�o de la palabra
    int tampal=strlen(pal);
    // Resultado, por defecto 0 (no encontrado)
    int res=0;
    
    // Si el primer caracter no coincide, no buscamos
    if(pal[0]!=sopa[y][x]){
        return 0;
    }
    
    /** Izquierda **/
    if(x-tampal+1>=0 && res==0){
       res=1;// Por defecto, consideramos que esta
       for(i=x-1;i>=x-tampal+1 && res==1;i--){
           if(pal[x-i]!=sopa[y][i])
               res=0;// Si descubrimos no esta, paramos de buscar
       } 
    }
    
    /** Derecha **/
    if(x+tampal-1<n && res==0){
       res=1;// Por defecto, consideramos que esta
       for(i=x+1;i<x+tampal && res==1;i++){
           if(pal[i-x]!=sopa[y][i])
               res=0;// Si descubrimos no esta, paramos de buscar
       } 
    }
    
    /** Arriba **/
    if(y-tampal+1>=0 && res==0){
       res=1;// Por defecto, consideramos que esta
       for(i=y-1;i>=y-tampal+1 && res==1;i--){
           if(pal[y-i]!=sopa[i][x])
               res=0;// Si descubrimos no esta, paramos de buscar
       } 
    }
    
    /** Abajo **/
    if(y+tampal-1<m && res==0){
       res=1;// Por defecto, consideramos que esta
       for(i=y+1;i<y+tampal && res==1;i++){
           if(pal[i-y]!=sopa[i][x])
               res=0;// Si descubrimos no esta, paramos de buscar
       } 
    }
    
    /** Abajo izquierda **/
    if(y+tampal-1<m  && x-tampal+1>=0 && res==0){
       res=1;// Por defecto, consideramos que esta
       for(i=y+1,j=x-1;i<y+tampal && j>=x-tampal+1 && res==1;i++,j--){
           if(pal[i-y]!=sopa[i][j])
               res=0;// Si descubrimos no esta, paramos de buscar
       } 
    }
    
    /** Abajo derecha **/
    if(y+tampal-1<m && x+tampal-1<n  && res==0){
       res=1;// Por defecto, consideramos que esta
       for(i=y+1,j=x+1;i<y+tampal  && j<x+tampal && res==1;i++,j++){
           if(pal[i-y]!=sopa[i][j])
               res=0;// Si descubrimos no esta, paramos de buscar
       } 
    }
    
    /** Arriba izquierda **/
    if(y-tampal+1>=0 && x-tampal+1>=0  && res==0){
       res=1;// Por defecto, consideramos que esta
       for(i=y-1,j=x-1;i>=y-tampal+1 && j>=x-tampal+1 && res==1;i--,j--){
           if(pal[y-i]!=sopa[i][j])
               res=0;// Si descubrimos no esta, paramos de buscar
       } 
    }
    
    /** Arriba derecha **/
    if(y-tampal+1>=0 && x+tampal-1<n  && res==0){
       res=1; // Por defecto, consideramos que esta
       for(i=y-1,j=x+1;i>=y-tampal+1 && j<x+tampal && res==1;i--,j++){
           if(pal[y-i]!=sopa[i][j])
               res=0; // Si descubrimos no esta, paramos de buscar
       } 
    }
    return res;
}

int main() { 
    int i,j,k;
    // Variables para las posiciones x,y de las palabras
    int xpal,ypal;
    int npab; // Cuantas palabras habra
    
    cin >> m >> n; // Leemos m y n
    char tmp;
    // Leemos caracter temporal, para luego poder leer lineas completas
    cin.get(tmp); 
    // Leemos las filas, y las pasamos a mayusculas.
    for(int i=0;i<m;i++){
        cin.getline(sopa[i],51,'\n');
        strupr(sopa[i]);
    }
    // Leemos cuantas palabras
    cin >> npab;
    // Caracter temporal, para leer luego lines completas
    cin.get(tmp);
    // Leemos todas las palabras
    for(i=0;i<npab;i++){
        xpal=0, ypal=0;
        // Centinela, indicando que en principio no se ha encontrado
        int encontrado=0;
        // Leemos palabra y la pasamos a mayusculas
        cin.getline(pal,51,'\n');
        strupr(pal);
        // Buscamos en el orden  para encontrar la mas arriba/iquierda
        // si en esa posicion empieza la palabra que tenemos
        // El centinela se pone a uno y acaba la busqueda
        for(j=0;j<m && !encontrado;j++){
            for(k=0;k<n && !encontrado;k++){
                // Funcion que devuelve si esta o no la palabra
                if(esta_pal(j,k)){
                    xpal=j;
                    ypal=k;
                    encontrado=1;
                }
            }
        }
        // Imprimimos la posici�n de la palabra
        cout << xpal+1 << " " << ypal+1 << endl;
    }
    return 0;
}
