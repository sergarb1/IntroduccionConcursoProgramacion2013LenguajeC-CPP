#include <iostream>
using namespace std;

int main()
{
    int contador;
    int cantidad;
    int numero;
    cin >> cantidad; // Leemos cuantos numeros
    for (int i=0;i<cantidad;i++){ // Ejecutamos el bucle tantas veces como numeros
        contador=1;// Ponemos el contador inicialmente a 1
        cin >> numero; // Leemos el numero
        while(numero!=1){ // Mientras sea distinto de 1, algoritmo y contamos
            contador++;// Sumamos 1 al contador
            if(numero%2==0){
                numero=numero/2;
            }
            else{
                numero=(numero*3)+1;
            }
        }
        cout << contador << endl;// Imprimimos contador seguido de un salto
    }
    return 0;
}
