#include <iostream>
using namespace std;
#define MAXTAM 100000
int resultados[MAXTAM];// Vector de 0 a 99999


int main()
{
    int i,j;
    // Inicio del pre-calculo
    for (int x=0;x<MAXTAM;x++){
        resultados[x]=0; // Inicializamos a cero (no usado)
    }    
    resultados[1]=1; // Caso base, ya sabemos el resultado
    for (int x=2;x<MAXTAM;x++){ // Ejecutamos el bucle tantas veces como numeros
        int ciclos=0; // Para llever la cuenta de ciclos en cada numero
        int num=x;// Auxiliar para operar con el numero actual
        while(num!=1) // Mientras no converja
        {
            ciclos++;
            if(num%2==0){
                num=num>>1;// equivalente a num=num/2;
            }
            else{
                num=(num*3)+1;
            }
            /* Aqui solo operamos si el resultado esta en el rango de
            posibles guardados y ademas esta guardado
            Eso signfica que ya tenemos soluci�n, asi que romperemos el bucle */
            if(num<MAXTAM && resultados[num]!=0){
                break;
            }
        }
        /* Asignamos el ultimo numero encontrado (en el peor caso sera el 1)
        mas los ciclos acumulados como resultado */
        resultados[x]=ciclos+resultados[num];
    }   
    // Fin del pre-calculo
    /* Con este tipod e linea como no sabemos cuantos pares i, j habra
    Leeremos i y j mientras haya datos de entrada */
    while(cin >>i >> j){ 
        if(i>j) // Caso de i mayor que j, algoritmo de intercambio
        {
            int aux=i;
            i=j;
            j=aux;
        }
        int maximo=0; // Maximo inicial de ciclos en un rango
        for (int x=i;x<=j;x++){ // Buscamos en el rango un ciclo mayor
            if(resultados[x]>maximo){
                maximo=resultados[x];
            }
        }
        cout << maximo << endl; // Imprimimos el mayor ciclo encontrado
    } 
    return 0;
}
