#include <iostream>

using namespace std;

// Hasta aqui liberias necesarias para que funcione C++

int main()
{
    // Correspondencias letra/numero
    char tabla[] = "TRWAGMYFPDXBNJZSQVHLCKE"; 
    // Declaramos la variable donde guardaremos el DNI
    int numeroDNI; 
    // Declaramos la variable donde guardaremos el DNI%23
    int numerom23;
    // Declaramos variable donde guardaremos la letra 
    char letra; 
    // Leemos de entrada estandard el numero del DNI
    cin >> numeroDNI; 
    // Obtenemos el resto de dividir por 23
    numerom23=numeroDNI%23; 
    // Guardamos el contenido de la posicion en letra
    letra=tabla[numerom23];
    // Imprimimos letra y un salto de linea final 
    cout << letra << endl; 
    return 0;
}
