#include <iostream>
#include <stack>
using namespace std;

int main() {
    // Declaro una pila de enteros
    stack<int> pila;
    int num;
    while (cin >> num){
        // Apilo el entero leido
        pila.push(num);
    }
    // Mientras la pila no este vacia
    while (!pila.empty()) {
        // Muestro el que esta arriba de la pila
        cout << pila.top()<<endl;
        // Desapilo el que esta arriba
        pila.pop();
    }
}
