#include <iostream>
#include <queue>
using namespace std;

int main() {
    // Declaramos dos colas con tipo interior string
    queue<string> colamayu, colaminu;
    // Usamos el tipo string de C++
    string cad;
    while (cin >> cad) {
        // Leemos palabras y las clasificamos en dos colas segun empiecen
        // por mayusculas o minusculas
        if (cad[0]>='A' and cad[0]<='Z'){
             colamayu.push(cad);
        }
        else{
             colaminu.push(cad);
        }
    }
    cout << "Hay " << colamayu.size()<< " palabras que empiezan por mayusculas"<<endl;
    while (!colamayu.empty()) {// Mientras haya algo en la cola
        cout << colamayu.front() << endl; // Imprimimos la actual
        colamayu.pop(); // Sacamos de la cola
    }
    cout << "Hay " << colaminu.size()<< " palabras que empiezan por minusculas"<<endl;
    
    while (!colaminu.empty()) {// Mientras haya algo en la cola
        cout << colaminu.front() << endl; // Imprimimos la actual
        colaminu.pop(); // Sacamos de la cola
    }
}
