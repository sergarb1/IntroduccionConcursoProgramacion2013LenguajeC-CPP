#include <iostream>
#include <stack>
#include <cstring>
using namespace std;

int main() {
    char parentesis[102];
    int tam;
    // Declaro una pila de caracteres
    stack<char> pila;
    cin >>  parentesis;
    tam=strlen(parentesis);
    // Recorremos todos los caracteres
    for(int i=0;i<tam;i++){
        // si es ( , apilamos
        if(parentesis[i]=='('){
            pila.push(parentesis[i]);
        }
        // Si es ) , desapilamos
        else{
            if(pila.size()>0){ 
                pila.pop();
            }
            // Si no podemos desapilar porque no quedan, mal cerrado
            else{
                cout << "NO" << endl;
                return 0;
            }
        }
    }
    // si al finalzar, queda alguno por cerrar, mal cerrado
    if(pila.size()>0){
        cout << "NO" << endl;
    }
    else{
        cout << "SI" << endl;
    }
    return 0;
}
