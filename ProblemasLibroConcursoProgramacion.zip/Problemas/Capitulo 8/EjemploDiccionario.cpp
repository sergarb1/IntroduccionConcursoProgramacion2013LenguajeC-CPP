#include <iostream>
#include <map>

using namespace std;


int main(){
    // Definimos un diccionario, cuya clave es un string y 
    // su contenido es otro string
    map<string, string> jugadores;
    // Con la clave Futbol, metemos el contenido Messi
    jugadores["Futbol"] = "Messi";
    // Con la clave Basket, metemos el contenido Gasol
    jugadores["Basket"] = "Gasol";
    cout << "De basket: " << jugadores["Basket"] << endl;
    cout << "De futbol: " << jugadores["Futbol"] << endl;
}
