#include <iostream>
using namespace std;
// Convierte un numero de decimal a otra base
void fromDec(int n, int b, char *s) {
	
    char digitos[40] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	int p = 0;

	if (n == 0)
		s[p++] = '0';
	
	// Tomamos restos de dividir por la base
	while (n != 0) {
		s[p] = digitos[n%b];
		n /= b;
		p++;
	}

	// invertir la cadena
	for (int i = 0; i < p/2; i++) {
		int t = s[i];
		s[i] = s[p-i-1];
		s[p-i-1] = t;
	}
	s[p] = '\0';
}

// convierte un n�mero a decimal
int toDec(char *s, int b) {
	int res = 0;
	int p = 0;
    // Aplicamos teorema fundamental de la numeraci�n
	while (s[p] != '\0') {
		int digito;
		if (s[p] >= '0' && s[p] <= '9')
			digito = s[p] - '0';
		else
			digito = s[p] - 'A' + 10;

		res = res*b + digito;
		p++;
	}
	return res;
}

int main(){
    char resultado[100]; // Donde guardaremos la conversi�n
    char num[100]; // Recordad algunas bases pueden llevar letras
    int baseActual,baseDeseada;
    cin >>  baseActual>> baseDeseada;
    cin >> num;
    // Si se desea la misma base actual, se imprime tal cual
    if(baseActual==baseDeseada){
        cout << num << endl;
    }
    // Si esta en base 10, solo pasamos a la deseada
    else if(baseActual==10){
        int n=atoi(num);
        fromDec(n,baseDeseada, resultado);
        cout << resultado<<endl;
    }
    // Si se desea base 10, se pasa a esa base y se imprime
    else if(baseDeseada==10){
        int n=toDec(num, baseActual);
        cout << n << endl;
    }
    // Cambio entre bases distintas a 10, pasar a base 10
    // y de ahi a la base deseada
    else{
        int n=toDec(num, baseActual);
        fromDec(n,baseDeseada, resultado);
        cout << resultado<<endl;
    }
    
}
