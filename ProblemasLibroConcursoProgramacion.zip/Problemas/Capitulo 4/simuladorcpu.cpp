#include <iostream>
#include <cstring> // Para usar funciones de cadena
using namespace std;
// Funcion que convierte un caracter en entero
int charToInt(char c){
    return c-'0';
}

int main(){
    int registros[5];
    char palabras[100][4]; // 100 palabras de 3 caracteres
    char paltmp[4];
    int posactual=0;
    int i;
    for(i=0;i<100;i++){
        strcpy(palabras[i],"100");// Inicializamos todas a 100
    }
    // Para leer palabras hasta que se acabe el fichero
    while(cin >> paltmp){
        strcpy(palabras[posactual],paltmp); // Copia paltmp en la posicion actual
        posactual++; // Posicion siguiente
    }
    posactual=0; // La posicion actual vuelve a 0
    do{
        // Extreamos de la palabra los 3 enteros
        int codigo=charToInt(palabras[posactual][0]);
        int operandoX=charToInt(palabras[posactual][1]);
        int operandoY=charToInt(palabras[posactual][2]);
        if(codigo==2) { // Operacion inicializar registro
            registros[operandoX]=operandoY;
        }
        else if(codigo==3){// Operacion valor de un registro X a Y
            registros[operandoY]=registros[operandoX];
        }
        else if(codigo==4){// Operacion suma al registro
            registros[operandoX]+=operandoY;
        }
        else if(codigo==5){// Operacion suma al registro
            registros[operandoX]*=operandoY;
        }
        else if(codigo==6){// Operacion valor de un registro a otro
            sprintf(paltmp,"%d",registros[operandoX]); // Entero a cadena
            strcpy(palabras[registros[operandoY]],paltmp);
        }
        posactual++; // Incrementamos la posicion actual
    }while(strcmp(palabras[posactual],"100")!=0); // Mientras la palabra actual no sea 100
    cout << posactual+1 << endl; // +1 para contar la instruccion 100
    return 0;
}
