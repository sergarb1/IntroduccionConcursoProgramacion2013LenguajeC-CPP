#include <iostream>
#include <cmath>
using namespace std;
// Funcion que devuelve 1 si es primo o 0 si no lo es
int esPrimo(int num){
    if(num==1){ // Caso de 1, no es primo
        return 0;
    }
    // Calculamos la raiz, y nos quedamos con la parte entera
    int raiz=(int)sqrt((double)num);
    for(int i=2;i<=raiz;i++){
        if(num%i==0){// Caso es divisible
            return 0; // Devolvemos no primo
        }
    }
    return 1; // Si ninguno ha sido divisible, devolvemos primo.
}

int main()
{
    int num;
    while(cin >> num){ // Leemos todos los primos
        if(esPrimo(num)){
            cout << "SI"<< endl;
        }
        else{
            cout << "NO"<<endl;
        }
    }
}
