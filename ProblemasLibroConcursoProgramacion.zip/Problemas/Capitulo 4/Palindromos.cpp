#include <iostream>
#include <cstring>
using namespace std;
// Funcion que devuelve uno si es palindromo 0 si no
int esPalindromo(char *cad){
    int tam=strlen(cad); // Saca el tama�o de la cadena
    int inicio=0, final =tam-1; // Establecemos inicio y final
    
    while(inicio<final){
        if(cad[inicio]!=cad[final]){ // Caso no palindromo
            return 0;
        }
        inicio++;// Inicio hacia adelante
        final--;// Final hacia atras
    }
    return 1;// Todos iguales, es palindromo
}

int main(){
    char cadena[201];// Cadena de 200 caracteres
    while(cin >> cadena) // Leemos cadenas
    {
        strlwr(cadena); // Pasa toda la cadena a minusculas
        if(esPalindromo(cadena)){
            cout << "SI" << endl;
        }
        else{
            cout << "NO" << endl;
        }
    }
    return 0;   
}
