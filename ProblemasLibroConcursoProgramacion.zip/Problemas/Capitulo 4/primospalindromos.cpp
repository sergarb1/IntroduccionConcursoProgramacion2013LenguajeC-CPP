#include <iostream>
#include <cmath>
using namespace std;
// Funcion que calcula si es primo o no 
int esPrimo(int num){
    if(num==1){ // Caso de 1, no es primo
        return 0;
    }
    // Calculamos la raiz, y nos quedamos con la parte entera
    int raiz=(int)sqrt((double)num);
    for(int i=2;i<=raiz;i++){
        if(num%i==0){// Caso es divisible
            return 0; // Devolvemos no primo
        }
    }
    return 1; // Si ninguno ha sido divisible, devolvemos primo.
}
// Funcion que recibe numero, si genera par o impar y los limites
void generar(int n,int esImpar,int limini,int limfin){
	char buffer[16];
	int ini, fin;
	int numero;

	sprintf(buffer,"%d",n);// Pasamos el numero a cadena
	// MArcamos el final y el inicio desde donde haremos el efecto espejo
	fin = strlen(buffer); 
	ini = fin - 1;

	while(ini >=0) { // Mientras quede cadena
        buffer[fin]=buffer[ini]; // Copiamos el caracter
		ini--; // Hacia atras
		fin++;// Hacia adelante
	}
	buffer[fin] = '\0'; // \0 final para el formato correcto de la cadena
    // Caso impar, a�adiremos del 0 al 9 enmedio
    if(esImpar==1){
        int tam=strlen(buffer)-1;
        int medio=tam/2;
        // Desplazamos los de detras del medio un hueco a la derecha
        for (int x=medio+1;x<=tam;x++){
            buffer[x+1]=buffer[x];
        }
        
        for (int x=0;x<=9;x++){
            // Truco para poner en medio el caracter correspondiente al numero
            buffer[medio+1]='0'+x; 
          	numero = atoi(buffer); // Pasamos a entero
          	// Si esta en el limite y es primo, imprimimos
            if(numero<=limfin && numero>=limini){
                if(esPrimo(numero)){
                    cout << numero << endl;
	            }
            }   
        }
    }
    else
    {
      	numero = atoi(buffer); // Pasamos a entero
      	// Si esta en el limite y es primo, imprimimos
        if(numero<=limfin && numero>=limini){
          if(esPrimo(numero)){
  		      cout << numero << endl;
	       }
        }
    }
}

int main(){
	int limini,limfin;
	int i;
    cin >> limini >> limfin;
    //Primero numeros del 5 al 9 directamente
    for (i = 5; i <= 9; i++)	{ 
        if(i<=limfin && i>=limini){ // Si estan en los limites
          if(esPrimo(i)){
  		      cout << i << endl;
	       }
        }
    }
	for (i = 1; i <= 999; i++)	{ //Calculamos pares e impares
		generar(i,0,limini,limfin); // Generamos pares 
		generar(i,1,limini,limfin); // Generamos impares
	}
	for (i = 1000; i <= 9999; i++)	{ // Aqui solo hacen falta pares
		generar(i,0,limini,limfin); // Generamos pares 
	}
    return 0;
}
