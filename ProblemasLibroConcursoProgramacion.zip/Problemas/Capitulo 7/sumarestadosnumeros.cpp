#include <iostream>

using namespace std;

int main(){
    int x,y,res;
    int contador=0;
    cin >> x >> y >> res; // Leemos lso datos
    /* Comprobamos las combinaciones para ver si coinciden con el resultado
    Ademas, tenemos en cuenta el efecto espejo para reducir combinaciones*/
    if(x+y==res){
        contador+=2;
    }
    if(-x+y==res){
        contador+=2;
    }
    if(x-y==res){
        contador+=2;
    }
    if(-x-y==res){
        contador+=2;
    }
    cout << contador << endl; //Mostramos el resultado
    return 0;
}
