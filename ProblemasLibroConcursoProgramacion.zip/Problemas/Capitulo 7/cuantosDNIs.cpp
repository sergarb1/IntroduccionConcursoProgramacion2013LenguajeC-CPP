#include <iostream>
#include <cstring>
using namespace std;

// Posicion 9, es la letra
int dniValido(char d[9]){
    // Correspondencias letra/numero
    char letra=d[8]; // Sacamos la letra
    char ntemp[9];
    // Pasamos a un temporal el numero sin letra
    // Para luego usar ATOI
    for (int i=0;i<8;i++){
        ntemp[i]=d[i];
    }
    ntemp[8]='\0';
    // Cadena a entero
    int ndni=atoi(ntemp);
    // Algoritmo calculo de DNI 
    char tabla[] = "TRWAGMYFPDXBNJZSQVHLCKE";
    char letrareal=tabla[ndni%23];
    // Si la letra real coincide con la que tenemos
    if(letra==letrareal){
        return 1; // DNI correcto
    }
    return 0; // Dni incorrecto
     
}

int calcular(char d[9],int posact,int tam){
    int i,j;
    int res=0;
    if(posact==tam){
        // Miramos si el dni generado es valido
        if(dniValido(d)){
            return 1;
        }
        return 0;
    }
    // Contamos si ha habido X o no
    int cuantasX=0;
    // Empezamos desde la posicion enviad
    // La letra no hay que tenerla en cuenta, por eso tam-1
    for(i=posact;i<tam-1;i++){
        if(d[i]=='X'){ // si la posicion es sustituible
            cuantasX=1; // Marcamos como que ha habido X
            for(j=0;j<=9;j++){
                d[i]='0'+j; // Truco para pasar int a char
                // Funcion recursiva
                res=res+calcular(d,i,tam); // Calculamos a partir de la posicion siguiente
                d[i]='X'; // Restauramos la X, para seguir generando combinaciones
            }
        }
    }
    // Caso de ninguna X, para ver si el dni que tenemos es valido
    if(cuantasX==0){
        // Miramos si el dni generado es valido
        if(dniValido(d)){
            return 1; // Devolvemos 1 si el dni es valido y no habia X
        }
    }
    // Devolvemos la cantidad encontrada
    return res;
}


int main(){
    char DNI[10];
    int resultado,N;
    cin >> N; // Leemos cantidad de numeros
    // Leemos cada numero y marcamos como no usado
    for (int i=0;i<N;i++){
        cin >> DNI;
        // Calculamos con la funcion recursiva e imprimimos
        resultado=calcular(DNI,0,strlen(DNI));
        cout << resultado << endl;
    }
    return 0;
}
