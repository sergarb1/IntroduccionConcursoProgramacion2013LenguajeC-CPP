#include <iostream>

using namespace std;

int numeros[5];
int usados[5];
int N,res;
int contador;

/* Funcion que recibe valor a sumar, "cantidad de numeros usados",
, el total de suma que llevamos por ahora y un vector
indicando que numeros se han usado 
*/
void calcular(int valor, int cant,int total,int usa[]){
    // Acumulamos el valor al totla
    int t=total+valor;
    int c=cant+1; // Sumamos un numero mas usado
    if(c==N){
        if(t==res){
            contador++;
        }
        return;
    }
    
    for (int i=0;i<N;i++)
    {
        // Si un numero no se ha usado...
        if(!usa[i]){ // Distinto de cero
           usa[i]=1; //Marcamos como usado
           calcular(numeros[i],c,t,usa);
           calcular(-numeros[i],c,t, usa);
           usa[i]=0; // Desmarcamos como usado
        }
    }
    
}

int main(){
    
    contador=0;
    cin >> N; // Leemos cantidad de numeros
    // Leemos cada numero y marcamos como no usado
    for (int i=0;i<N;i++){
        cin >> numeros[i]; 
        usados[i]=0;
    }
    cin >> res;



    for (int i=0;i<N;i++)
    {
        usados[i]=1; // Marcamos numero como usado
        
        // llamamos a la funcion con valores iniciales
        // y tanto en positivo como en negativo

        // Caso base, 0 usados, 0 total
    
        calcular(numeros[i],0,0,usados);
        calcular(-numeros[i],0,0, usados);
        // Desmarcamos numero como usado
        usados[i]=0;
    }
    cout << contador << endl; //Mostramos el resultado
    return 0;
}
