#include <iostream>
#include <cstring>
#include <cstdlib>

using namespace std;

// Funcion usada en Qsort, compara dos letras y devuelve su relacion de orden
int comparar
(const void *_a, const void *_b) { 
        char *a, *b;
        a = (char *) _a;
        b = (char *) _b;
        return (*a - *b); // Basandose valor ASCII de las letras
}

int anagrama(char *p1,char *p2){
    int tam1=strlen(p1); // Tamanyo de las palabras
    int tam2=strlen(p2);
    
    // Las ordenadmos las palabras
    
    qsort(p1, tam1, sizeof(char), &comparar);
    qsort(p2, tam2, sizeof(char), &comparar);
         
    // Al ordenar, el problema se reduce a ver si se puede formar o no
    
    int contador=0;
    // Recorremos la segunda entera
    for(int i=0;i<tam2 && contador<tam1;i++){
        // Cada coincidencia, avanzamos una posicion la primera
        if(p1[contador]==p2[i]){
            contador++;
        }
    }
    // Si ha llegado al final la primera, es que se podia formar
    if(contador==tam1){
        return tam2-tam1;
    }
    // Caso contrario, no se podia formar
    else{
        return -1;
    }
}

int main(){
    char pal1[101],pal2[102]; // Palabras a comparar, 100 caracteres
    int N;
    int res;
    char tmp;
    cin >> N; // Leemos el total de casos de prueba
    
    cin.get(tmp); // Caracter temporal
    for (int i=0;i<N;i++){
        // Leemos las palabras
        cin.getline(pal1,100,'\n');
        cin.getline(pal2,100,'\n');
        // Vemos cuantas hay que eliminar o si no se puede
        res=anagrama(pal1,pal2);
        if(res==-1){
            cout << "IMPOSIBLE"<< endl;
        }
        else{
            cout << res << endl;
        }
    }
    return 0;
}
