#include <iostream>
#include <cstring>
#include <cstdlib>

using namespace std;

// Vector para almacenar 100000 enteros
int enteros[100000];

// Funcion usada en Qsort, compara dos enteros y devuelve su relacion de orden
int comparar
(const void *_a, const void *_b) { 
        int *a, *b;
        a = (int *) _a;
        b = (int *) _b;
        return (*a - *b);
}

int main(){
    int tam=0;
    while(cin >> enteros[tam]){
        tam++; // Incrementamso tam para guardar el siguiente
    }
    // Ordenamos
    qsort(enteros, tam, sizeof(int), &comparar);
    // Imprimimos el vector ordenado
    for(int i=0;i<tam;i++){
        cout << enteros[i]<<endl;
    }
    return 0;
}
