#include <iostream>
#include <cstring>
#include <cstdlib>

using namespace std;
typedef struct {
    char nombre[101];
    int peso;
    int altura;
} pesoAltura;

// Vector para almacenar 100000 pares peso/altura
pesoAltura valores[100000];

// Funcion usada en Qsort, compara dos enteros y devuelve su relacion de orden
int comparar
(const void *_a, const void *_b) { 
        pesoAltura *a, *b;
        pesoAltura tmpa, tmpb;
        a = (pesoAltura *) _a;
        b = (pesoAltura *) _b;
        tmpa=*a;
        tmpb=*b;
        /* Ordenamos de mayor a menor, fijaros orden de la resta*/
        // PEsos diferentes, decide el peso
        if(tmpa.peso!=tmpb.peso){
            return tmpb.peso-tmpa.peso;
        }
        // Pesos iguales, decide la altura
        else{
            return tmpb.altura-tmpa.altura;
        }
}

int main(){
    int tam=0;
    char tmp; // Para leer caracter temporal salto de linea
    while(cin >> valores[tam].nombre){
        cin >> valores[tam].peso;
        cin >> valores[tam].altura;
        // Leemos caracter temporal salto de linea
        cin.get(tmp);
        tam++; // Incrementamso tam para guardar el siguiente
    }
    // Ordenamos por valor absoluto
    qsort(valores, tam, sizeof(pesoAltura), &comparar);
    // Imprimimos el vector ordenado
    for(int i=0;i<tam;i++){
        cout << valores[i].nombre <<endl;
    }
    return 0;
}
